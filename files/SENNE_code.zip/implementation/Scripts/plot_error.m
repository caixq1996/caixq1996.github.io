error_index1 = find(result_label ~= streamdatalabel & result_label == 1);
error_index2 = find(result_label ~= streamdatalabel & result_label == 2);
error_index3 = find(result_label ~= streamdatalabel & result_label == 999);
i1 = find(result_label == 1);
ii1 = find(streamdata == 2);
i2 = find(result_label == 2);
ii2 = find(streamdata == 1);
num = 1;
error_index12 = [];
for i = 1 : size(i1,1)
    for j = 1 : size(ii1,1)
        if i1(i) == ii1(j)
            error_index12(num) = i1(i);
            num = num + 1;
            break;
        end
    end
end
for i = 1 : size(i2,1)
    for j = 1 : size(ii2,1)
        if i2(i) == ii2(j)
            error_index12(num) = i2(i);
            num = num + 1;
            break;
        end
    end
end
error_point1 = streamdata(error_index1,:);
error_point2 = streamdata(error_index2,:);
error_point3 = streamdata(error_index3,:);
index1 = find(streamdatalabel == 1);
index2 = find(streamdatalabel == 2);
index3 = find(streamdatalabel == 999);
data1 = streamdata(index1,:);
data2 = streamdata(index2,:);
data3 = streamdata(index3,:);
Index1 = find(alltraindatalabel == 1);
Index2 = find(alltraindatalabel == 2);
Data1 = alltraindata(Index1,:);
Data2 = alltraindata(Index2,:);
t1 = d2 - d1;
t2 = d3 - d2;
plot(data1(:,1),data1(:,2),'ro','MarkerSize',10,'markerfacecolor', [ 0, 0, 1 ]);
hold on
plot(data2(:,1),data2(:,2),'bo','MarkerSize',10,'markerfacecolor', [ 0, 1, 0 ]);
plot(data3(:,1),data3(:,2),'go','MarkerSize',10,'markerfacecolor', [ 1, 0, 0 ]);
plot(error_point1(:,1),error_point1(:,2),'o','MarkerSize',10,'markerfacecolor', [ 1, 1, 0 ]);
plot(error_point2(:,1),error_point2(:,2),'o','MarkerSize',10,'markerfacecolor', [ 0, 1, 1 ]);
plot(error_point3(:,1),error_point3(:,2),'o','MarkerSize',10,'markerfacecolor', [ 0, 0, 0 ]);
title({['Cur acc = ',num2str(acc),' %'];['Building model ',num2str(t1),' s'];['Prediction ',num2str(t2),' s']});