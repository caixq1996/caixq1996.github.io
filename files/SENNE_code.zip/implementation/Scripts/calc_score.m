function [label,score] = calc_score(B,testpoint,threshold)
score = 1;
r = inf;
label = 0;
iscore = 1;
for i = 1 : size(B,1)
    dis = Dist(testpoint,B{i,1});
    if dis <= B{i,2} && r > dis
        r = dis;
        score = 1 - B{i,4} / dis;
        if score < iscore && score <= threshold
            iscore = score;
            label = B{i,3};
        end
    end
end
end