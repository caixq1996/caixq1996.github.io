# Code of SENNE (**Nearest Neighbor Ensembles: An Effective Method for Difficult Problems in Streaming Classification with Emerging New Classes**)

## Files
* demo: script that you can directly run on synthetic dataset
### Scripts:
* getData: script that turn normal dataset into stream data with known classes and new class, and split dataset into training set and test set
* model_SENNE: function of build models
* Predict: function of predicting classes of test dataset
* modelupdate: function of updating models using data in the buffer
* calc_score: function of calculating New Class Score
* hyperSphere: function of building hypersphere clusters
* plot_error: plot results intuitively

### Data:
The `.mat` file contains synthetic dataset used in the paper.

## Citation
If there are any questions, please feel free to contact with me: Xin-Qiang Cai
(caixq@lamda.nju.edu.cn).

Please cite our work if you feel the paper or the code are helpful.

	@inproceedings{icdm_Cai0PMXY19,
	  author    = {Xin-Qiang Cai and
	               Peng Zhao and
	               Kai-Ming Ting and
	               Xin Mu and
	               Yuan Jiang},
	  title     = {Nearest Neighbor Ensembles: An Effective Method for Difficult Problems in Streaming Classification with Emerging New Classes},
	  booktitle = {{IEEE} International Conference on Data Mining, {ICDM} 2019, Beijing, China,
	               November 8-11, 2019},
	  year      = {2019}
	}